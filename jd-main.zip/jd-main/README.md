<article class="markdown-body entry-content container-lg" itemprop="text"><h1><a id="user-content-使用教程" class="anchor" aria-hidden="true" href="#使用教程"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a><a href="https://jdwxx.github.io/JD/" rel="nofollow">使用教程</a></h1>
<h2><a id="user-content-特别声明" class="anchor" aria-hidden="true" href="#特别声明"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>特别声明:</h2>
<ul>
<li>
拉库命令：</br>
ql repo https://ghproxy.com/https://github.com/wsn888/jd.git "jd_|jx_|gua_|wsn_|jdCookie" "" "^jd[^_]|jd_Cookie|magic|cleancart_activity|ZooFaker_Necklace|USER|JD|JDJR|utils|function|sign|ql|sendNotify"
</li>
<br>
<li>
2.28号新建QQ交流群：955063081</br>
<a target="_blank" href="https://qm.qq.com/cgi-bin/qm/qr?k=9Sj3XOUI_UDu5j9Z1Aw2Xy8TWJa1oN22&jump_from=webapi"><p>点击👉一键加群👈</p></a>
<img src="https://s3.bmp.ovh/imgs/2022/02/0d029dfb4510914e.png" alt="临时库-交流" title="临时库-交流">
</li>
<li>
<p>本仓库发布的jd项目中涉及的任何解锁和解密分析脚本，仅用于测试和学习研究，禁止用于商业用途，不能保证其合法性，准确性，完整性和有效性，请根据情况自行判断.</p>
</li>
<li>
<p>本项目内所有资源文件，禁止任何公众号、自媒体进行任何形式的转载、发布.</p>
</li>
<li>
<p>作者对任何脚本问题概不负责，包括但不限于由任何脚本错误导致的任何损失或损害.</p>
</li>
<li>
<p>间接使用脚本的任何用户，包括但不限于建立VPS或在某些行为违反国家/地区法律或相关法规的情况下进行传播, lxk0301 对于由此引起的任何隐私泄漏或其他后果概不负责.</p>
</li>
<li>
<p>请勿将Script项目的任何内容用于商业或非法目的，否则后果自负.</p>
</li>
<li>
<p>如果任何单位或个人认为该项目的脚本可能涉嫌侵犯其权利，则应及时通知并提供身份证明，所有权证明，我们将在收到认证文件后删除相关脚本.</p>
</li>
<li>
<p>任何以任何方式查看此项目的人或直接或间接使用该Script项目的任何脚本的使用者都应仔细阅读此声明。作者保留随时更改或补充此免责声明的权利。一旦使用并复制了任何相关脚本或Script项目的规则，则视为您已接受此免责声明.</p>
</li>
</ul>
<p><strong>您必须在下载后的24小时内从计算机或手机中完全删除以上内容.</strong>  <br></p>
<blockquote>
<p><em><strong>您使用或者复制了本仓库且本人制作的任何脚本，则视为<code>已接受</code>此声明，请仔细阅读</strong></em></p>
</blockquote>
